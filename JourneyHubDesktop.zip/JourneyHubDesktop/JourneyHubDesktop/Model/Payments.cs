﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqToDB.Mapping;

namespace JourneyHubDesktop.Model
{
    public class Payments
    {
        [PrimaryKey, Identity]
        public int      Payments_ID    { get; set; }
        public int      Reservation_ID { get; set; }
        public decimal  Amount;
        public DateTime Payment_Date   { get; set; }
        public string   Payment_Method { get; set; }
        public Payments(int Resid, decimal amount, DateTime paymentDate, string paymentMethod)
        {
            Reservation_ID = Resid;
            Amount = amount;
            Payment_Date = paymentDate;
            Payment_Method = paymentMethod;
        }

    }
}
