﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqToDB.Mapping;

namespace JourneyHubDesktop.Model
{
    public class Clients
    {
        [PrimaryKey, Identity] 
        public int    Clients_ID    { get; set; }
        public string First_Name { get; set; }
        public string Last_Name  {  get; set; }
        public string Email      { get; set; }
        public string Phone      { get; set; }


        public Clients(string Fname,string Lname,string email,string phone) { 
        
            
            this.First_Name = Fname;
            this.Last_Name = Lname; 
            this.Email = email;
            this.Phone = phone;
        }


    } 
}
