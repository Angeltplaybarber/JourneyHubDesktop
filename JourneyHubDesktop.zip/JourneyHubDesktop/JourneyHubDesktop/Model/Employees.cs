﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqToDB.Mapping;
using Microsoft.SqlServer.Server;

namespace JourneyHubDesktop.Model
{
    public class Employees
    {
        [PrimaryKey, Identity]
        public int    Employees_ID { get; set; }
        public string First_Name   { get; set; }
        public string Last_Name    { get; set; }
        public string Email        { get; set; }
        public string Phone        { get; set; }

        public Employees(string firstname,string lastname,string email,string phone) { 
        
           
            this.First_Name = firstname;
            this.Last_Name = lastname;
            this.Email = email;
            this.Phone = phone;
        }

    }
}
