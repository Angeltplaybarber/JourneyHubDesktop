﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using LinqToDB.Mapping;

namespace JourneyHubDesktop.Model
{
    public class Packages
    {

        [PrimaryKey, Identity]
        public int      PackageID { get; set; }

        public string   Name      { get; set; }   
        public string   Description {  get; set; }

        public int      TypeID {  get; set; }
        public decimal  Price {  get; set; }


        public Packages(string name,string description,int typeid,decimal price) {
        
        
            this.Name = name;   
            this.Description = description;
            this.TypeID = typeid;
            this.Price = price;
        }
    }
}
