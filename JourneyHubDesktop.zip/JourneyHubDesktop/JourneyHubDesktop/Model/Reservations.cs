﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqToDB.Mapping;

namespace JourneyHubDesktop.Model
{
    public class Reservations
    {
        [PrimaryKey, Identity]
        public int Reservation_ID   { get; set; }
        public int Client_ID         { get; set; }
        public int Package_ID        { get; set; }
        public int Reservation_Date  { get; set; }
        public int Number_Of_People { get; set; }
        public decimal Total_Price  { get; set; }
        public int Employee_ID      { get; set; }

        public Reservations(int client_ID, int package_ID, int reservation_Date, int number_Of_People, decimal total_Price, int employee_ID)
        {
          
            Client_ID = client_ID;
            Package_ID = package_ID;
            Reservation_Date = reservation_Date;
            Number_Of_People = number_Of_People;
            Total_Price = total_Price;
            Employee_ID = employee_ID;
        }
    }
}
