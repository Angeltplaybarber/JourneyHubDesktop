﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static JourneyHubDesktop.Aplications;


namespace JourneyHubDesktop
{

    public partial class Form1 : Form
    {
        private Aplications PackagesView;
        private Aplications ClientsView;
        private Aplications ReservationsView;
        private Aplications PaymentsView;
        public static string constring = "Server=ANGEL\\SQLEXPRESS;Database=JourneyHub;TrustServerCertificate=True;integrated security  = True";

        static public int SwitchAPP;
        static public bool CondiUpda = false;
        static public int IDSELECT;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
             PackagesView = new Aplications();
             ClientsView = new Aplications();
             ReservationsView = new Aplications();
             PaymentsView = new Aplications();

            // Agregar los controles al GroupBox
            groupBox2.Controls.Add(PackagesView);
            groupBox2.Controls.Add(ClientsView);
            groupBox2.Controls.Add(ReservationsView);
            groupBox2.Controls.Add(PaymentsView);
            PackagesView.Dock = DockStyle.Fill;
            ClientsView.Dock = DockStyle.Fill;
            ReservationsView.Dock = DockStyle.Fill;
            PaymentsView.Dock = DockStyle.Fill;






            // ocultar todos los controles
            HideAllViews();
        }

        private void HideAllViews()
        {
           // Aplications
           PackagesView.Visible = false;
           ClientsView.Visible = false;
           ReservationsView.Visible = false;
           PaymentsView.Visible = false;

           
        }
        private void ClientsBtn_Click(object sender, EventArgs e)
        {
            HideAllViews();  
            ClientsView.Visible = true;  // Mostrar la vista de clientes  
            SwitchAPP = 1;
        }

        private void PackageBtn_Click(object sender, EventArgs e)
        {
            HideAllViews(); 
            PackagesView.Visible = true;  // Mostrar la vista de paquetes
            SwitchAPP = 2;

        }

        private void ReservationsBtn_Click(object sender, EventArgs e)
        {
            HideAllViews();  
            ReservationsView.Visible = true;  // Mostrar la vista de reservas
            SwitchAPP = 3;

        }

        private void PaymentsBtn_Click(object sender, EventArgs e)
        {
            HideAllViews();  // Ocultar todas las vistas
            PaymentsView.Visible = true;  // Mostrar la vista de pagos
            SwitchAPP = 4;

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
