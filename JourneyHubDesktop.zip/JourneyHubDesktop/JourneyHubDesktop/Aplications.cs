﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static JourneyHubDesktop.Adding;


namespace JourneyHubDesktop
{
    public partial class Aplications : UserControl
    {

        private Lists PackagesList;
        private Lists UsersList;
        private Lists ReservationsList;
        private Lists PaymentsList;


        public Aplications()
        {
            InitializeComponent();

            //Lists of Applications
            PackagesList = new Lists();
            UsersList = new Lists();
            ReservationsList = new Lists();
            PaymentsList = new Lists();

            AppgroupBox2.Controls.Add(PackagesList);
            AppgroupBox2.Controls.Add(UsersList);
            AppgroupBox2.Controls.Add(ReservationsList);
            AppgroupBox2.Controls.Add(PaymentsList);

            PackagesList.Dock = DockStyle.Bottom;
            UsersList.Dock = DockStyle.Bottom;
            ReservationsList.Dock = DockStyle.Bottom;
            PaymentsList.Dock = DockStyle.Bottom;
           








        HideAllViews();

        }
        
        private void ViewBtn_Click(object sender, EventArgs e)
        {
          
            switch (Form1.SwitchAPP)
            {

                case 1:
                    {
                        HideAllViews();
                        UsersList.Visible = true;
                        string table = "Clients"; 
                        UsersList.displayTable(table);
                        UsersList.label1.Text = "Listado de Clientes";
                    }
                    break;
                case 2:
                    {
                        HideAllViews();
                        PackagesList.Visible = true;
                        string table = "Packages";
                        PackagesList.displayTable(table);
                        PackagesList.label1.Text = "Listado de Paquetes";
                    }
                    break;
                case 3:
                    {
                        HideAllViews();
                        ReservationsList.Visible = true;
                        string table = "Reservations";
                        ReservationsList.displayTable(table);
                        ReservationsList.label1.Text = "Listado de Reservaciones";
                    }
                    break;
                case 4:
                    {
                        HideAllViews();
                        PaymentsList.Visible = true;
                        string table = "Payments";
                        PaymentsList.displayTable(table);
                        PaymentsList.label1.Text = "Listado de Pagos";
                    }
                    break;


            }

        }

            
        private void EditBtn_Click(object sender, EventArgs e)
        {
            AddParametrer result=null;
            DataGridViewRow filaSeleccionada = null;


            try
            {
                // Verificar que hay una fila seleccionada
                if (UsersList.dataGridView1.SelectedRows.Count > 0 || PackagesList.dataGridView1.SelectedRows.Count > 0 || ReservationsList.dataGridView1.SelectedRows.Count > 0 || PaymentsList.dataGridView1.SelectedRows.Count > 0)
                {
                    // Obtener la fila seleccionada
                    switch (Form1.SwitchAPP)
                    {

                        case 1:
                            {
                                filaSeleccionada = UsersList.dataGridView1.SelectedRows[0];
                                 Form1.IDSELECT = Convert.ToInt32(filaSeleccionada.Cells["Client_ID"].Value);
                                result = UsersList.GetId(Form1.IDSELECT, "clients", "Client_ID");
                                result.valorid = Form1.IDSELECT;

                            }
                            break;
                        case 2:
                            {
                                filaSeleccionada = PackagesList.dataGridView1.SelectedRows[0];
                                Form1.IDSELECT = Convert.ToInt32(filaSeleccionada.Cells["Package_ID"].Value);
                                result = PackagesList.GetId(Form1.IDSELECT, "Packages", "Package_ID");
                                result.valorid = Form1.IDSELECT;

                            }
                            break;
                        case 3:
                            {
                                filaSeleccionada = ReservationsList.dataGridView1.SelectedRows[0];
                                Form1.IDSELECT = Convert.ToInt32(filaSeleccionada.Cells["Reservation_ID"].Value);
                                result = ReservationsList.GetId(Form1.IDSELECT, "Reservations", "Reservation_ID");
                                result.valorid = Form1.IDSELECT;

                            }
                            break;
                        case 4:
                            {
                                filaSeleccionada = PaymentsList.dataGridView1.SelectedRows[0];
                                Form1.IDSELECT = Convert.ToInt32(filaSeleccionada.Cells["Payment_ID"].Value);
                                result = PaymentsList.GetId(Form1.IDSELECT, "Payments", "Payment_ID");
                                result.valorid = Form1.IDSELECT;

                            }
                            break;



                    }

                }
                else
                {
                    MessageBox.Show("Por favor, selecciona una fila.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al obtener el ID: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            switch (Form1.SwitchAPP)
            {
                case 1:
                    {
                        try
                        {

                        Form1.CondiUpda = true;
                        Adding add = new Adding();
                      
                        
                        add.label1.Text = "Nombre";
                        add.label2.Text = "Apellido";
                        add.label3.Text = "Email";
                        add.label4.Text = "Phone";
                        add.SaveBtn.Image = global::JourneyHubDesktop.Properties.Resources._4105935_edit_pencil_update_113934;
                        add.Text = "Editando...";
                         
                        
                        add.textBox1.Text = result.valor1;
                        add.textBox3.Text = result.valor2;
                        add.textBox2.Text = result.valor3;
                        add.textBox4.Text = result.valor4;
                        add.ShowDialog();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Disculpa pero hubo un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }


                    }
                    break;
                case 2:
                    {
                        try
                        {

                        Form1.CondiUpda = true;
                        Adding add = new Adding();
                        add.label1.Text = "Nombre";
                        add.label2.Text = "Description";
                        add.label3.Text = "Type_ID";
                        add.label4.Text = "Price";
                        add.Text = "Editando...";
                        add.SaveBtn.Image = global::JourneyHubDesktop.Properties.Resources._4105935_edit_pencil_update_113934;

                        add.textBox1.Text = result.valor1;
                        add.textBox3.Text = result.valor2;
                        add.textBox2.Text = result.valor3;
                        add.textBox4.Text = result.valor4;
                        add.ShowDialog();

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Disculpa pero hubo un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    break;
                case 3:
                    {
                        try
                        {

                        Form1.CondiUpda = true;
                        Adding1 add = new Adding1();
                        add.label1.Text = "IDCliente";
                        add.label2.Text = "IDPaquete";
                        add.label3.Text = "IDEmpleado";
                        add.label4.Text = "Precio total";
                        add.label5.Text = "Dia de la Reservacion";
                        add.label6.Text = "Numero de Personas";
                        add.SaveBtn.Image = global::JourneyHubDesktop.Properties.Resources._4105935_edit_pencil_update_113934;

                        add.textBox1.Text = result.valor1;
                        add.textBox3.Text = result.valor2; 
                        add.textBox2.Text = result.valor3;
                        add.textBox4.Text = result.valor4;
                        add.textBox5.Text = result.valor6;
                        add.dateTimePicker1.Value = result.valor5;
                        add.ShowDialog();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Disculpa pero hubo un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        //add



                    }
                    break;
                case 4:
                    {
                        try
                        {

                        Form1.CondiUpda = true;
                        AddingPay add = new AddingPay();
                        add.label1.Text = "IDReservacion";
                        add.label2.Text = "IDCliente";
                        add.label3.Text = "Dia del Pago";
                        add.label4.Text = "Selecciona el metodo de pago";
                        add.label5.Text = "Precio Total";
                        add.SaveBtn.Image = global::JourneyHubDesktop.Properties.Resources._4105935_edit_pencil_update_113934;
                        add.textBox1.Text = result.valor1;
                       add.textBox3.Text = result.valor3;
                        add.textBox4.Text = result.valor2; 
                        add.dateTimePicker1.Value = result.valor5;
                        add.comboBox1.Text = result.valor4;
                        add.ShowDialog();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Disculpa pero hubo un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    break;


            }
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            switch (Form1.SwitchAPP)
            {
                case 1:
                    {
                        Form1.CondiUpda = false;
                        Adding add = new Adding();
                        add.label1.Text = "Nombre";
                        add.label2.Text = "Apellido";
                        add.label3.Text = "Email";
                        add.label4.Text = "Phone";
                        add.ShowDialog();

                      


                    }
                    break;
                case 2:
                    {
                        Form1.CondiUpda = false;
                        Adding add = new Adding();
                        add.label1.Text = "Nombre";
                        add.label2.Text = "Description";
                        add.label3.Text = "TypeID";
                        add.label4.Text = "Price";
                        add.ShowDialog();

                    }
                    break;
                case 3:
                    {
                        Form1.CondiUpda = false;
                        Adding1 add = new Adding1();
                        add.label1.Text = "IDCliente";
                        add.label2.Text = "IDPaquete";
                        add.label3.Text = "IDEmpleado";
                        add.label4.Text = "Precio total";
                        add.label5.Text = "Dia de la Reservacion";
                        add.label6.Text = "Numero de Personas";
                        add.ShowDialog();

                    }
                    break;
                case 4:
                    {
                        Form1.CondiUpda = false;
                        AddingPay add = new AddingPay();
                        add.label1.Text = "IDReservacion";
                        add.label2.Text = "IDCliente";
                        add.label3.Text = "Dia del Pago";
                        add.label4.Text = "Selecciona el metodo de pago";
                        add.label5.Text = "Precio Total";
                        
                        add.ShowDialog();
                    }
                    break;
                    

            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            

            AddParametrer result = null;
            DataGridViewRow filaSeleccionada = null;

            Adding adding = new Adding();

            try
            {
                // Verificar que hay una fila seleccionada
                if (UsersList.dataGridView1.SelectedRows.Count > 0 || PackagesList.dataGridView1.SelectedRows.Count > 0 || ReservationsList.dataGridView1.SelectedRows.Count > 0 || PaymentsList.dataGridView1.SelectedRows.Count > 0)
                {
                    // Obtener la fila seleccionada
                    switch (Form1.SwitchAPP)
                    {

                        case 1:
                            {
                                filaSeleccionada = UsersList.dataGridView1.SelectedRows[0];
                                Form1.IDSELECT = Convert.ToInt32(filaSeleccionada.Cells["Client_ID"].Value);
                                result = UsersList.GetId(Form1.IDSELECT, "clients", "Client_ID");
                                result.valorid = Form1.IDSELECT;
                                Dele(result);
                            }
                            break;
                        case 2:
                            {
                                filaSeleccionada = PackagesList.dataGridView1.SelectedRows[0];
                                Form1.IDSELECT = Convert.ToInt32(filaSeleccionada.Cells["Package_ID"].Value);
                                result = PackagesList.GetId(Form1.IDSELECT, "Packages", "Package_ID");
                                result.valorid = Form1.IDSELECT;
                                Dele(result);
                            }
                            break;
                        case 3:
                            {
                                filaSeleccionada = ReservationsList.dataGridView1.SelectedRows[0];
                                Form1.IDSELECT = Convert.ToInt32(filaSeleccionada.Cells["Reservation_ID"].Value);
                                result = ReservationsList.GetId(Form1.IDSELECT, "Reservations", "Reservation_ID");
                                result.valorid = Form1.IDSELECT;
                                Dele(result);
                            }
                            break;
                        case 4:
                            {
                                filaSeleccionada = PaymentsList.dataGridView1.SelectedRows[0];
                                Form1.IDSELECT = Convert.ToInt32(filaSeleccionada.Cells["Payment_ID"].Value);
                                result = PaymentsList.GetId(Form1.IDSELECT, "Payments", "Payment_ID");
                                result.valorid = Form1.IDSELECT;
                                Dele(result);

                            }
                            break;



                    }

                }
                else
                {
                    MessageBox.Show("Por favor, selecciona una fila.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al obtener el ID: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        public void Dele(AddParametrer addParametrer)
        {
            int valorid = addParametrer.valorid;
            addParametrer.condition = Form1.SwitchAPP;
            string table;
            string query;

            // Validar condición para determinar la tabla
            switch (addParametrer.condition)
            {
                case 1:
                    table = "Clients";
                    query = $"DELETE FROM {table} WHERE Client_ID = @valorid";
                    break;
                case 2:
                    table = "Packages";
                    query = $"DELETE FROM {table} WHERE Package_ID = @valorid";
                    break;
                case 3:
                    table = "Reservations";
                    query = $"DELETE FROM {table} WHERE Reservation_ID = @valorid";
                    break;
                case 4:
                    table = "Payments";
                    query = $"DELETE FROM {table} WHERE Payment_ID = @valorid";
                    break;
                default:
                    MessageBox.Show("Condición no válida. No se pudo determinar la tabla.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
            }

            using (SqlConnection connection = new SqlConnection(Form1.constring))
            {
                try
                {
                    // Crear el comando con la consulta
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Agregar el parámetro para prevenir SQL Injection
                        command.Parameters.AddWithValue("@valorid", addParametrer.valorid);

                        // Abrir la conexión y ejecutar el comando
                        connection.Open();
                        command.ExecuteNonQuery();

                        
                            MessageBox.Show("El dato ha sido borrado exitosamente.", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Error en la base de datos: {ex.Message}", "Error SQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ha ocurrido un error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        

        }

        private void HideAllViews()
        {
            // List
            PackagesList.Visible = false;
            UsersList.Visible = false;
            ReservationsList.Visible = false;
            PaymentsList.Visible = false;

    


        }

        private void AppgroupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}