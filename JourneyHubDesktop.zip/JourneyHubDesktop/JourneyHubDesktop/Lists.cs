﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static JourneyHubDesktop.Adding;

namespace JourneyHubDesktop
{
    public partial class Lists : UserControl
    {
        public Lists()
        {
            InitializeComponent();
            

        }
        AddParametrer addParametrer = new AddParametrer();
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Lists_Load(object sender, EventArgs e)
        {

        }
        
        public void displayTable(string _table)
        {
            try
            {
                
                using (SqlConnection con = new SqlConnection(Form1.constring))
                {
                    con.Open();
                    string query = $"Select * From {_table}";
                    SqlCommand command = new SqlCommand(query, con);
                    SqlDataAdapter data = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    data.Fill(dataTable); 
                    if (dataTable.Rows.Count > 0)
                    {
                     
                        dataGridView1.DataSource = dataTable;

                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Ocurrió un error al cargar los datos:{ex.Message}",
                        "Error de Conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }
        public AddParametrer GetId(int id, string _table, string valorid)
        {
            int resultadoId = -1; // Valor predeterminado para indicar que no se encontró un resultado.

            try
            {
                // Construcción de la cadena de conexión
                using (SqlConnection con = new SqlConnection(Form1.constring))
                {
                    // Consulta dinámica con parámetros
                    string query = $"SELECT * FROM {_table} WHERE {valorid} = @Id";

                    // Crear comando
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        // Agregar parámetro para evitar inyección SQL
                        command.Parameters.AddWithValue("@Id", id);

                        // Abrir conexión
                        con.Open();

                        // Leer datos
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read()) // Si hay datos
                            {
                              //  resultadoId = reader.GetInt32(0); // Obtener el primer valor (id)
                                switch (Form1.SwitchAPP)
                                {
                                    case 1:
                                        {
                                            return new AddParametrer
                                            {
                                                valorid = (int)reader["Client_ID"],
                                                valor1 = reader["First_Name"].ToString(),
                                                valor2 = reader["Last_Name"].ToString(),
                                                valor3 = reader["Email"].ToString(),
                                                valor4 = reader["Phone"].ToString(),
                                            };
                                        }break;
                                    case 2:
                                        {
                                            return new AddParametrer
                                            {
                                                valorid = (int)reader["Package_ID"],
                                                valor1 = reader["Name"].ToString(),
                                                valor2 = reader["Description"].ToString(),
                                                valor3 = reader["Type_ID"].ToString(),
                                                valor4 = reader["Price"].ToString(),
                                            };
                                        }break;
                                      case 3:
                                        {
                                            return new AddParametrer
                                            {
                                                valorid = (int)reader["Reservation_ID"],
                                                valor1 = reader["Client_ID"].ToString(),
                                                valor2 = reader["Package_ID"].ToString(),
                                                valor6 = reader["Number_Of_People"].ToString(),
                                                valor4 = reader["Total_Price"].ToString(),
                                                valor5 = (DateTime)reader["Reservation_Date"],
                                                valor3 = reader["Employee_ID"].ToString(),

                                            };

                                        }break;
                                    case 4:
                                        {
                                            return new AddParametrer
                                            {
                                                valorid = (int)reader["Payment_ID"],
                                                valor1 = reader["Reservation_ID"].ToString(),
                                                valor2 = reader["Amount"].ToString(),
                                                valor3 = reader["Client_ID"].ToString(),
                                                valor5 = (DateTime)reader["Payment_Date"],
                                                valor4 = reader["Payment_Method"].ToString(),

                                               
                                            };

                                        }break;

                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Manejo de errores
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return null; // Retornar el id encontrado o -1 si no se encontró
        }

        public void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
