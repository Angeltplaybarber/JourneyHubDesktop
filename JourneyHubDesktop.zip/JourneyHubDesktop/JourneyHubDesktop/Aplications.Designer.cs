﻿namespace JourneyHubDesktop
{

    
    partial class Aplications
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;



       

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.ViewBtn = new System.Windows.Forms.Button();
            this.EditBtn = new System.Windows.Forms.Button();
            this.AddBtn = new System.Windows.Forms.Button();
            this.AppgroupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.DeleteBtn);
            this.groupBox1.Controls.Add(this.ViewBtn);
            this.groupBox1.Controls.Add(this.EditBtn);
            this.groupBox1.Controls.Add(this.AddBtn);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(955, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.DeleteBtn.Image = global::JourneyHubDesktop.Properties.Resources._1486564399_close_81512;
            this.DeleteBtn.Location = new System.Drawing.Point(825, 16);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(127, 81);
            this.DeleteBtn.TabIndex = 3;
            this.DeleteBtn.Text = "Borrar elemento";
            this.DeleteBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.DeleteBtn.UseVisualStyleBackColor = true;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // ViewBtn
            // 
            this.ViewBtn.Image = global::JourneyHubDesktop.Properties.Resources._3844441_eye_see_show_view_watch_110305;
            this.ViewBtn.Location = new System.Drawing.Point(584, 13);
            this.ViewBtn.Name = "ViewBtn";
            this.ViewBtn.Size = new System.Drawing.Size(127, 81);
            this.ViewBtn.TabIndex = 2;
            this.ViewBtn.Text = "Ver Listado";
            this.ViewBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ViewBtn.UseVisualStyleBackColor = true;
            this.ViewBtn.Click += new System.EventHandler(this.ViewBtn_Click);
            // 
            // EditBtn
            // 
            this.EditBtn.Image = global::JourneyHubDesktop.Properties.Resources._4105935_edit_pencil_update_113934;
            this.EditBtn.Location = new System.Drawing.Point(269, 13);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(127, 81);
            this.EditBtn.TabIndex = 1;
            this.EditBtn.Text = "Editar";
            this.EditBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.EditBtn.UseVisualStyleBackColor = true;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.Dock = System.Windows.Forms.DockStyle.Left;
            this.AddBtn.Image = global::JourneyHubDesktop.Properties.Resources.Plus_368512;
            this.AddBtn.Location = new System.Drawing.Point(3, 16);
            this.AddBtn.Margin = new System.Windows.Forms.Padding(50);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(124, 81);
            this.AddBtn.TabIndex = 0;
            this.AddBtn.Text = "Añadir";
            this.AddBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.AddBtn.UseVisualStyleBackColor = true;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // AppgroupBox2
            // 
            this.AppgroupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AppgroupBox2.Location = new System.Drawing.Point(0, 100);
            this.AppgroupBox2.Name = "AppgroupBox2";
            this.AppgroupBox2.Size = new System.Drawing.Size(955, 520);
            this.AppgroupBox2.TabIndex = 0;
            this.AppgroupBox2.TabStop = false;
            this.AppgroupBox2.Enter += new System.EventHandler(this.AppgroupBox2_Enter);
            // 
            // Aplications
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.Controls.Add(this.AppgroupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Aplications";
            this.Size = new System.Drawing.Size(955, 620);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox AppgroupBox2;
        private System.Windows.Forms.Button DeleteBtn;
        private System.Windows.Forms.Button ViewBtn;
        private System.Windows.Forms.Button EditBtn;
        private System.Windows.Forms.Button AddBtn;
    }
}
