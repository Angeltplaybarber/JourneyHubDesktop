﻿namespace JourneyHubDesktop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PaymentsBtn = new System.Windows.Forms.Button();
            this.ReservationsBtn = new System.Windows.Forms.Button();
            this.PackageBtn = new System.Windows.Forms.Button();
            this.ClientsBtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.UserNameLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.groupBox1.Controls.Add(this.PaymentsBtn);
            this.groupBox1.Controls.Add(this.ReservationsBtn);
            this.groupBox1.Controls.Add(this.PackageBtn);
            this.groupBox1.Controls.Add(this.ClientsBtn);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(186, 577);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // PaymentsBtn
            // 
            this.PaymentsBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.PaymentsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PaymentsBtn.Image = global::JourneyHubDesktop.Properties.Resources.cash_payments_payment_wallet_ecommerce_icon_2249511;
            this.PaymentsBtn.Location = new System.Drawing.Point(3, 305);
            this.PaymentsBtn.Name = "PaymentsBtn";
            this.PaymentsBtn.Size = new System.Drawing.Size(180, 63);
            this.PaymentsBtn.TabIndex = 4;
            this.PaymentsBtn.Text = "Pagos";
            this.PaymentsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.PaymentsBtn.UseVisualStyleBackColor = true;
            this.PaymentsBtn.Click += new System.EventHandler(this.PaymentsBtn_Click);
            // 
            // ReservationsBtn
            // 
            this.ReservationsBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ReservationsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReservationsBtn.Image = global::JourneyHubDesktop.Properties.Resources.weekly_calendar_icon_icons_com_56749;
            this.ReservationsBtn.Location = new System.Drawing.Point(3, 242);
            this.ReservationsBtn.Name = "ReservationsBtn";
            this.ReservationsBtn.Size = new System.Drawing.Size(180, 63);
            this.ReservationsBtn.TabIndex = 3;
            this.ReservationsBtn.Text = "Reservaciones";
            this.ReservationsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.ReservationsBtn.UseVisualStyleBackColor = true;
            this.ReservationsBtn.Click += new System.EventHandler(this.ReservationsBtn_Click);
            // 
            // PackageBtn
            // 
            this.PackageBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.PackageBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PackageBtn.Image = global::JourneyHubDesktop.Properties.Resources.travel_journey_04_icon_icons_com_56012;
            this.PackageBtn.Location = new System.Drawing.Point(3, 179);
            this.PackageBtn.Name = "PackageBtn";
            this.PackageBtn.Size = new System.Drawing.Size(180, 63);
            this.PackageBtn.TabIndex = 2;
            this.PackageBtn.Text = "Paquetes";
            this.PackageBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.PackageBtn.UseVisualStyleBackColor = true;
            this.PackageBtn.Click += new System.EventHandler(this.PackageBtn_Click);
            // 
            // ClientsBtn
            // 
            this.ClientsBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ClientsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClientsBtn.Image = global::JourneyHubDesktop.Properties.Resources.tab_client_icon_icons_com_72436;
            this.ClientsBtn.Location = new System.Drawing.Point(3, 116);
            this.ClientsBtn.Name = "ClientsBtn";
            this.ClientsBtn.Size = new System.Drawing.Size(180, 63);
            this.ClientsBtn.TabIndex = 1;
            this.ClientsBtn.Text = "Clientes";
            this.ClientsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.ClientsBtn.UseVisualStyleBackColor = true;
            this.ClientsBtn.Click += new System.EventHandler(this.ClientsBtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(this.UserNameLabel);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(3, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(180, 100);
            this.panel1.TabIndex = 0;
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.Location = new System.Drawing.Point(73, 72);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(40, 13);
            this.UserNameLabel.TabIndex = 1;
            this.UserNameLabel.Text = "Angelo";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.pictureBox1.Image = global::JourneyHubDesktop.Properties.Resources.Gender_Neutral_User_icon_icons_com_55902;
            this.pictureBox1.Location = new System.Drawing.Point(46, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(89, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(186, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(765, 577);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(951, 577);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(126)))), ((int)(((byte)(249)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "JourneyHubDesktop";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label UserNameLabel;
        private System.Windows.Forms.Button PaymentsBtn;
        private System.Windows.Forms.Button ReservationsBtn;
        private System.Windows.Forms.Button PackageBtn;
        private System.Windows.Forms.Button ClientsBtn;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

