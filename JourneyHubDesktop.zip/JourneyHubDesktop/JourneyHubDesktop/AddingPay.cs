﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static JourneyHubDesktop.Adding;

namespace JourneyHubDesktop
{
    public partial class AddingPay : Form
    {
        public AddingPay()
        {
            InitializeComponent();
            comboBox1.Items.Add("Efectivo");
            comboBox1.Items.Add("Trasferencia Bancaria");
            comboBox1.Items.Add("Tarjeta de Debito");
            comboBox1.Items.Add("Tarjeta de Credito");
           

        }
            Adding adding = new Adding();


        private void SaveBtn_Click(object sender, EventArgs e)
        {
            AddParametrer addParametrer = new AddParametrer();

            addParametrer.valor1 = textBox1.Text;
            addParametrer.valor3 = textBox3.Text;

            addParametrer.valor2 = textBox4.Text;
            addParametrer.condition = Form1.SwitchAPP;
            addParametrer.valor5 = dateTimePicker1.Value;
            addParametrer.valor4 = comboBox1.Text;
            addParametrer.valorid = Form1.IDSELECT;


            adding.Insert(addParametrer);
            textBox1.Clear();

            textBox3.Clear();
            textBox4.Clear();
            Close();

        }

        private void AddingPay_Load(object sender, EventArgs e)
        {

        }
    }
}
