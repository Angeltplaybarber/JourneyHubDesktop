﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static JourneyHubDesktop.Adding;

namespace JourneyHubDesktop
{
    public partial class Adding1 : Form
    {
        public Adding1()
        {
            InitializeComponent();
        }

         Adding adding = new Adding();

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            AddParametrer addParametrer = new AddParametrer();

            addParametrer.valor1 = textBox1.Text;
            addParametrer.valor2 = textBox3.Text;
            addParametrer.valor3 = textBox2.Text;
            addParametrer.valor4 = textBox4.Text;
            addParametrer.condition = Form1.SwitchAPP;
            addParametrer.valor5 = dateTimePicker1.Value;
            addParametrer.valor6 = textBox5.Text;
            addParametrer.valorid = Form1.IDSELECT;



            adding.Insert(addParametrer);
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            Close();
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Adding1_Load(object sender, EventArgs e)
        {

        }

        private void Adding1_Load_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
