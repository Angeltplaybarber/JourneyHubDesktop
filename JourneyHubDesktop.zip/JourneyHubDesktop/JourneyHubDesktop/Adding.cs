﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JourneyHubDesktop.Model;
using LinqToDB.Common;

namespace JourneyHubDesktop
{
    public partial class Adding : Form
    {
        public Adding()
        {
            InitializeComponent();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {

            AddParametrer addParametrer = new AddParametrer();

            addParametrer.valor1 = textBox1.Text;
            addParametrer.valor2 = textBox3.Text;
            addParametrer.valor3 = textBox2.Text;
            addParametrer.valor4 = textBox4.Text;
            addParametrer.condition = Form1.SwitchAPP;
            addParametrer.valorid = Form1.IDSELECT;
            Insert(addParametrer);
            Close();

        }
        public void Insert(AddParametrer addParametrer)
        {

            // Query

           
            string table;
            string query;
            if (Form1.CondiUpda == true)
            {
                using (SqlConnection connection = new SqlConnection(Form1.constring))
                {
                    try
                    {
                        switch (addParametrer.condition)
                        {
                            case 1:
                                {
                                    table = "Clients";
                                    int valorid = addParametrer.valorid;
                                    query = $"Update {table} set First_Name = @valor1, Last_Name = @valor2, Email = @valor3,Phone = @valor4 where {valorid} = Client_ID";
                                    // Creating command
                                    SqlCommand command = new SqlCommand(query, connection);

                                    // params to SqlInyection
                                    command.Parameters.AddWithValue("@valor1", addParametrer.valor1);
                                    command.Parameters.AddWithValue("@valor2", addParametrer.valor2);
                                    command.Parameters.AddWithValue("@valor3", addParametrer.valor3);
                                    command.Parameters.AddWithValue("@valor4", addParametrer.valor4);


                                    connection.Open();

                                    // Command
                                    command.ExecuteNonQuery();

                                    //Alert
                                    MessageBox.Show("El dato ha sido actualizado correctamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                break;
                            case 2:
                                {
                                    int valorid = addParametrer.valorid;
                                    table = "Packages";
                                    query = $"Update {table} set Name= @valor1 , Description = @valor2, Type_ID= @valor3,Price= @valor4 where {valorid} = Package_ID";
                                    // Creating command
                                    SqlCommand command = new SqlCommand(query, connection);

                                    // params to SqlInyection
                                    command.Parameters.AddWithValue("@valor1", addParametrer.valor1);
                                    command.Parameters.AddWithValue("@valor2", addParametrer.valor2);
                                    command.Parameters.AddWithValue("@valor3", Convert.ToInt32(addParametrer.valor3));
                                    command.Parameters.AddWithValue("@valor4", Convert.ToDecimal(addParametrer.valor4));


                                    connection.Open();

                                    // Command
                                    command.ExecuteNonQuery();

                                    //Alert
                                    MessageBox.Show("El dato ha sido actualizado correctamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                break;
                            case 3:
                                {
                                    int valorid = addParametrer.valorid;
                                    table = "Reservations";
                                    query = $"Update {table} set Client_ID = @valor1, Package_ID = @valor2, Reservation_Date = @valor5, Number_Of_People = @valor6, Total_Price = @valor4, Employee_ID = @valor3 where {valorid} = Reservation_ID";
                                    // Creating command
                                    SqlCommand command = new SqlCommand(query, connection);

                                   

                                    command.Parameters.AddWithValue("@valor1", Convert.ToInt32(addParametrer.valor1));
                                    command.Parameters.AddWithValue("@valor2", Convert.ToInt32(addParametrer.valor2));
                                    command.Parameters.AddWithValue("@valor5", addParametrer.valor5);
                                    command.Parameters.AddWithValue("@valor3", Convert.ToInt32(addParametrer.valor3));
                                    command.Parameters.AddWithValue("@valor4", Convert.ToDecimal(addParametrer.valor4));
                                    command.Parameters.AddWithValue("@valor6", Convert.ToInt32(addParametrer.valor6));

                                    connection.Open();

                                    // Command
                                    command.ExecuteNonQuery();

                                    //Alert
                                    MessageBox.Show("El dato ha sido actualizado correctamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                break;
                            case 4:
                                {
                                    int valorid = addParametrer.valorid;
                                    table = "Payments";
                                    query = $"Update {table} set Reservation_ID = @valor1, Amount = @valor2, Payment_Date = @valor5, Payment_Method = @valor4, Client_ID = @valor3 where {valorid} = Payment_ID";
                                    // Creating command
                                    SqlCommand command = new SqlCommand(query, connection);

                                    // params to SqlInyection
                                    command.Parameters.AddWithValue("@valor1", Convert.ToInt32(addParametrer.valor1));
                                    command.Parameters.AddWithValue("@valor2", Convert.ToDecimal(addParametrer.valor2));
                                    command.Parameters.AddWithValue("@valor3", addParametrer.valor3);
                                    command.Parameters.AddWithValue("@valor4", addParametrer.valor4);
                                    command.Parameters.AddWithValue("@valor5", addParametrer.valor5);




                                connection.Open();

                                    // Command
                                    command.ExecuteNonQuery();

                                    //Alert
                                    MessageBox.Show("El dato ha sido actualizado correctamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                break;


                        }




                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("El dato no se ha podido actualizar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {

                // Using connection
                using (SqlConnection connection = new SqlConnection(Form1.constring))
                {
                    try
                    {
                        switch (addParametrer.condition)
                        {
                            case 1:
                                {
                                    table = "Clients";
                                    query = $"INSERT INTO {table} (First_Name, Last_Name, Email,Phone) VALUES (@valor1, @valor2, @valor3,@valor4)";
                                    // Creating command
                                    SqlCommand command = new SqlCommand(query, connection);

                                    // params to SqlInyection
                                    command.Parameters.AddWithValue("@valor1", addParametrer.valor1);
                                    command.Parameters.AddWithValue("@valor2", addParametrer.valor2);
                                    command.Parameters.AddWithValue("@valor3", addParametrer.valor3);
                                    command.Parameters.AddWithValue("@valor4", addParametrer.valor4);


                                    connection.Open();

                                    // Command
                                    command.ExecuteNonQuery();

                                    //Alert
                                    MessageBox.Show("El dato ha sido insertado correctamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                break;
                            case 2:
                                {
                                    table = "Packages";
                                    query = $"INSERT INTO {table} (Name, Description, Type_ID,Price) VALUES (@valor1, @valor2, @valor3,@valor4)";
                                    // Creating command
                                    SqlCommand command = new SqlCommand(query, connection);

                                    // params to SqlInyection
                                    command.Parameters.AddWithValue("@valor1", addParametrer.valor1);
                                    command.Parameters.AddWithValue("@valor2", addParametrer.valor2);
                                    command.Parameters.AddWithValue("@valor3", Convert.ToInt32(addParametrer.valor3));
                                    command.Parameters.AddWithValue("@valor4", Convert.ToDecimal(addParametrer.valor4));


                                    connection.Open();

                                    // Command
                                    command.ExecuteNonQuery();

                                    //Alert
                                    MessageBox.Show("El dato ha sido insertado correctamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                break;
                            case 3:
                                {
                                    table = "Reservations";
                                    query = $"INSERT INTO {table} (Client_ID,Package_ID,Reservation_Date,Number_Of_People,Total_Price,Employee_ID) VALUES (@valor1, @valor2, @valor5,@valor3,@valor4,@valor6)";
                                    // Creating command
                                    SqlCommand command = new SqlCommand(query, connection);

                                    // params to SqlInyection
                                    command.Parameters.AddWithValue("@valor1", Convert.ToInt32(addParametrer.valor1));
                                    command.Parameters.AddWithValue("@valor2", Convert.ToInt32(addParametrer.valor2));
                                    command.Parameters.AddWithValue("@valor5", addParametrer.valor5);
                                    command.Parameters.AddWithValue("@valor3", Convert.ToInt32(addParametrer.valor3));
                                    command.Parameters.AddWithValue("@valor4", Convert.ToDecimal(addParametrer.valor4));
                                    command.Parameters.AddWithValue("@valor6", Convert.ToInt32(addParametrer.valor6));


                                    connection.Open();

                                    // Command
                                    command.ExecuteNonQuery();

                                    //Alert
                                    MessageBox.Show("El dato ha sido insertado correctamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                break;
                            case 4:
                                {
                                    table = "Payments";
                                    query = $"INSERT INTO {table} (Reservation_ID, Amount, Payment_Date,Payment_Method,Client_ID) VALUES (@valor1, @valor2, @valor5,@valor4,@valor3)";
                                    // Creating command
                                    SqlCommand command = new SqlCommand(query, connection);

                                    // params to SqlInyection
                                    command.Parameters.AddWithValue("@valor1", Convert.ToInt32(addParametrer.valor1));
                                    command.Parameters.AddWithValue("@valor2", Convert.ToDecimal(addParametrer.valor2));
                                    command.Parameters.AddWithValue("@valor3", addParametrer.valor3);
                                    command.Parameters.AddWithValue("@valor4", addParametrer.valor4);
                                    command.Parameters.AddWithValue("@valor5", addParametrer.valor5);


                                    connection.Open();

                                    // Command
                                    command.ExecuteNonQuery();

                                    //Alert
                                    MessageBox.Show("El dato ha sido insertado correctamente", "Completado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                break;


                        }




                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("El dato no se ha podido insertar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }


        }


        public partial class AddParametrer {


            public int valorid { get; set; } // valor 1 

            public string valor1 { get; set; }
            public string valor2 { get; set; }
            public string valor3 { get; set; }
            public string valor4 { get; set; }
            public int condition { get; set; }
            public DateTime valor5 { get; set; }
            public string  valor6 {  get; set; }
          
        }

        private void Adding_Load(object sender, EventArgs e)
        {

        }

        private void Adding_Load_1(object sender, EventArgs e)
        {

        }

        private void Adding_Load_2(object sender, EventArgs e)
        {

        }
    }
}
